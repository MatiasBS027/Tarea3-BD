import { setEstado as setEstadoEl, logout, escapeHtml } from './utils.js';
class EmpleadosPage {
    constructor() {
        this.empleadoConsultado = null;
        this.filtroInput = document.getElementById('filtro');
        this.buscarBtn = document.getElementById('buscarBtn');
        this.limpiarBtn = document.getElementById('limpiarBtn');
        this.mensajeDiv = document.getElementById('mensaje');
        this.contadorSpan = document.getElementById('contador');
        this.empleadosBody = document.getElementById('empleadosBody');
        this.detallePanel = document.getElementById('detallePanel');
        this.detalleContenido = document.getElementById('detalleContenido');
        this.detalleTitulo = document.getElementById('detalleTitulo');
        this.detalleEstado = document.getElementById('detalleEstado');
        this.detalleCerrarBtn = document.getElementById('detalleCerrarBtn');
        this.logoutBtn = document.getElementById('logoutBtn');
        this.bindEvents();
        this.cargarEmpleados();
    }
    bindEvents() {
        this.buscarBtn.addEventListener('click', () => {
            void this.cargarEmpleados();
        });
        this.limpiarBtn.addEventListener('click', () => {
            this.filtroInput.value = '';
            void this.cargarEmpleados();
        });
        if (this.detalleCerrarBtn) {
            this.detalleCerrarBtn.addEventListener('click', () => {
                this.cerrarDetalle();
            });
        }
        this.filtroInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                void this.cargarEmpleados();
            }
        });
        this.empleadosBody.addEventListener('click', (event) => {
            const target = event.target;
            const button = target?.closest('button[data-accion]');
            if (!button)
                return;
            const documento = button.dataset.documento;
            if (!documento)
                return;
            const accion = button.dataset.accion;
            if (accion === 'consultar') {
                void this.consultarEmpleado(documento);
                return;
            }
            if (accion === 'impersonar') {
                void this.impersonarEmpleado(documento);
            }
        });
        if (this.logoutBtn) {
            this.logoutBtn.addEventListener('click', () => {
                logout();
            });
        }
    }
    cerrarDetalle() {
        this.detallePanel.classList.add('hidden');
        this.empleadoConsultado = null;
    }
    async cargarEmpleados() {
        this.cerrarDetalle();
        const filtro = this.filtroInput.value.trim();
        const token = localStorage.getItem('authToken') || '';
        const headers = {};
        if (token)
            headers['Authorization'] = 'Bearer ' + token;
        this.setEstado('Cargando empleados...', 'info');
        this.setBotones(false);
        try {
            const response = await fetch(`/api/empleados?filtro=${encodeURIComponent(filtro)}`, {
                method: 'GET',
                headers,
            });
            const payload = await response.json();
            if (!response.ok || !payload.success) {
                this.limpiarTabla();
                this.setEstado(payload.message || 'No se pudieron obtener los empleados.', 'error');
                this.contadorSpan.textContent = '0 resultados';
                return;
            }
            const empleados = payload.data ?? [];
            this.renderTabla(empleados);
            this.contadorSpan.textContent = `${empleados.length} resultado${empleados.length === 1 ? '' : 's'}`;
            if (empleados.length === 0) {
                this.setEstado('No se encontraron empleados con ese filtro.', 'warning');
            }
            else {
                this.setEstado('Empleados cargados correctamente.', 'success');
            }
        }
        catch (error) {
            console.error('Error cargando empleados:', error);
            this.limpiarTabla();
            this.contadorSpan.textContent = '0 resultados';
            this.setEstado('Error de conexión con el servidor.', 'error');
        }
        finally {
            this.setBotones(true);
        }
    }
    renderTabla(empleados) {
        this.empleadosBody.innerHTML = '';
        if (empleados.length === 0) {
            this.empleadosBody.innerHTML = `
                <tr>
                    <td colspan="4" class="empty-state">Todavía no hay datos cargados</td>
                </tr>
            `;
            return;
        }
        for (const empleado of empleados) {
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td>${escapeHtml(empleado.Nombre)}</td>
                <td>${escapeHtml(empleado.ValorDocumento)}</td>
                <td>${escapeHtml(empleado.NombrePuesto)}</td>
                <td>
                    <button type="button" class="action-button action-view" data-accion="consultar" data-documento="${escapeHtml(empleado.ValorDocumento)}">
                        Consultar
                    </button>
                    <button type="button" class="action-button action-impersonar" data-accion="impersonar" data-documento="${escapeHtml(empleado.ValorDocumento)}">
                        Impersonar
                    </button>
                </td>
            `;
            this.empleadosBody.appendChild(fila);
        }
    }
    limpiarTabla() {
        this.empleadosBody.innerHTML = `
            <tr>
                <td colspan="4" class="empty-state">Todavía no hay datos cargados</td>
            </tr>
        `;
    }
    async impersonarEmpleado(valorDocumentoIdentidad) {
        const token = localStorage.getItem('authToken') || '';
        const headers = { 'Content-Type': 'application/json' };
        if (token)
            headers['Authorization'] = 'Bearer ' + token;
        this.setEstado('Impersonando empleado...', 'info');
        try {
            const response = await fetch('/api/empleados/impersonar', {
                method: 'POST',
                headers,
                body: JSON.stringify({ valorDocumento: valorDocumentoIdentidad }),
            });
            const payload = await response.json();
            if (!response.ok || !payload.success) {
                this.setEstado(payload.message || 'No se pudo impersonar al empleado.', 'error');
                return;
            }
            const idEmpleado = payload.data?.idEmpleado;
            if (!idEmpleado) {
                this.setEstado('El SP no devolvió el id del empleado.', 'error');
                return;
            }
            this.setEstado('Empleado impersonado. Redirigiendo...', 'success');
            localStorage.setItem('empleadoImpersonadoId', String(idEmpleado));
            localStorage.setItem('empleadoImpersonadoDoc', valorDocumentoIdentidad);
            setTimeout(() => {
                window.location.href = `/empleado-view.html?id=${idEmpleado}`;
            }, 500);
        }
        catch (error) {
            console.error('Error impersonando empleado:', error);
            this.setEstado('Error de conexión al impersonar.', 'error');
        }
    }
    async consultarEmpleado(valorDocumentoIdentidad) {
        // Toggle: si es el mismo empleado, cerrar
        if (this.empleadoConsultado === valorDocumentoIdentidad) {
            this.cerrarDetalle();
            return;
        }
        this.empleadoConsultado = valorDocumentoIdentidad;
        this.detallePanel.classList.remove('hidden');
        this.detalleTitulo.textContent = `Consulta de ${valorDocumentoIdentidad}`;
        this.detalleEstado.textContent = 'Cargando detalle del empleado...';
        this.detalleEstado.className = 'status info';
        this.detalleContenido.innerHTML = '';
        try {
            const token = localStorage.getItem('authToken') || '';
            const headers = {};
            if (token)
                headers['Authorization'] = 'Bearer ' + token;
            const response = await fetch(`/api/empleados/${encodeURIComponent(valorDocumentoIdentidad)}`, { headers });
            const payload = await response.json();
            if (!response.ok || !payload.success || !payload.data) {
                this.detalleEstado.textContent = payload.message || 'No se pudo cargar el detalle.';
                this.detalleEstado.className = 'status error';
                this.detalleContenido.innerHTML = '';
                return;
            }
            const detalle = payload.data;
            const rawFecha = detalle.FechaContratacion ?? '';
            let fechaContratacion = '';
            if (rawFecha) {
                try {
                    const d = new Date(rawFecha);
                    if (!isNaN(d.getTime())) {
                        fechaContratacion = d.toLocaleDateString('es-ES');
                    }
                    else {
                        fechaContratacion = String(rawFecha);
                    }
                }
                catch {
                    fechaContratacion = String(rawFecha);
                }
            }
            this.detalleEstado.textContent = 'Detalle cargado correctamente.';
            this.detalleEstado.className = 'status success';
            this.detalleContenido.innerHTML = `
                <div class="detalle-grid">
                    <div class="detalle-item">
                        <span class="detalle-label">Documento</span>
                        <span class="detalle-valor">${escapeHtml(detalle.ValorDocumento)}</span>
                    </div>
                    <div class="detalle-item">
                        <span class="detalle-label">Nombre</span>
                        <span class="detalle-valor">${escapeHtml(detalle.Nombre)}</span>
                    </div>
                    <div class="detalle-item">
                        <span class="detalle-label">Puesto</span>
                        <span class="detalle-valor">${escapeHtml(detalle.NombrePuesto)}</span>
                    </div>
                    <div class="detalle-item">
                        <span class="detalle-label">Fecha contratación</span>
                        <span class="detalle-valor">${fechaContratacion}</span>
                    </div>
                    <div class="detalle-item">
                        <span class="detalle-label">Estado</span>
                        <span class="detalle-valor">${detalle.Activo ? 'Activo' : 'Inactivo'}</span>
                    </div>
                </div>
            `;
        }
        catch (error) {
            console.error('Error consultando empleado:', error);
            this.detalleEstado.textContent = 'Error de conexión con el servidor.';
            this.detalleEstado.className = 'status error';
            this.detalleContenido.innerHTML = '';
        }
    }
    setEstado(texto, tipo) {
        setEstadoEl(this.mensajeDiv, texto, tipo);
    }
    setBotones(habilitado) {
        this.buscarBtn.disabled = !habilitado;
        this.limpiarBtn.disabled = !habilitado;
    }
}
document.addEventListener('DOMContentLoaded', () => {
    new EmpleadosPage();
});
